#   @author: 马朝威 1570858572@qq.com
#   @time: 2019-02-24 17:32

name = my_decorator

def main():
    pass


if __name__ == "__main__":
    main()









