from setuptools import setup

setup(
    name='toolofsamma',
    version='1.0',
    packages=['mydecorate'],
    url='',
    license='',
    author='samma',
    author_email='1570858572@qq.com',
    description='the private tool of samma'
)
